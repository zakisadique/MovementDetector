/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "global.h"
#include "led.h"
#include "uart.h"

uint16_t ADCBuffer[1024];

#if 0
/* Defines for DMA_ADC_MEM */
#define DMA_ADC_MEM_BYTES_PER_BURST 1
#define DMA_ADC_MEM_REQUEST_PER_BURST 1
#define DMA_ADC_MEM_SRC_BASE (CYDEV_PERIPH_BASE)
#define DMA_ADC_MEM_DST_BASE (CYDEV_SRAM_BASE)

/* Variable declarations for DMA_ADC_MEM */
/* Move these variable declarations to the top of the function */
uint8 DMA_ADC_MEM_Chan;
uint8 DMA_ADC_MEM_TD[1];
#endif

/* Defines for DMA_ADC_MEM */
#define DMA_ADC_MEM_BYTES_PER_BURST 2
#define DMA_ADC_MEM_REQUEST_PER_BURST 1
#define DMA_ADC_MEM_SRC_BASE (CYDEV_PERIPH_BASE)
#define DMA_ADC_MEM_DST_BASE (CYDEV_SRAM_BASE)

/* Variable declarations for DMA_ADC_MEM */
/* Move these variable declarations to the top of the function */
uint8 DMA_ADC_MEM_Chan;
uint8 DMA_ADC_MEM_TD[1];


/* Defines for DMA_MEM_UART */
#define DMA_MEM_UART_BYTES_PER_BURST 2
#define DMA_MEM_UART_REQUEST_PER_BURST 1
#define DMA_MEM_UART_SRC_BASE (CYDEV_SRAM_BASE)
#define DMA_MEM_UART_DST_BASE (CYDEV_PERIPH_BASE)

/* Variable declarations for DMA_MEM_UART */
/* Move these variable declarations to the top of the function */
uint8 DMA_MEM_UART_Chan;
uint8 DMA_MEM_UART_TD[1];















//ISR which will increment the systick counter every ms
ISR(systick_handler)
{
    CounterTick(cnt_systick);
}




int main()
{
    CyGlobalIntEnable; /* Enable global interrupts. */
   
    //Set systick period to 1 ms. Enable the INT and start it.
	EE_systick_set_period(MILLISECONDS_TO_TICKS(1, BCLK__BUS_CLK__HZ));
	EE_systick_enable_int();
    

    
    // Start Operating System
    for(;;)	    
    	StartOS(OSDEFAULTAPPMODE);
}

void unhandledException()
{
    //Ooops, something terrible happened....check the call stack to see how we got here...
    __asm("bkpt");
}

/********************************************************************************
 * Task Definitions
 ********************************************************************************/

TASK(tsk_init)
{
    
    //Init MCAL Drivers

//    UART_Logs_Start();
//    UART_Logs_PutString("Ready to receive data\n");
    
    UART_init();
    ADC_DelSig_Start();
    Clock_1_Start();
    
    //Reconfigure ISRs with OS parameters.
    //This line MUST be called after the hardware driver initialisation!
    EE_system_init();
	
    //Start SysTick
	//Must be done here, because otherwise the isr vector is not overwritten yet
    EE_systick_start();  

    

//#if 0   
///* DMA Configuration for DMA_ADC_MEM */
//DMA_ADC_MEM_Chan = DMA_ADC_MEM_DmaInitialize(DMA_ADC_MEM_BYTES_PER_BURST, DMA_ADC_MEM_REQUEST_PER_BURST, 
//    HI16(DMA_ADC_MEM_SRC_BASE), HI16(DMA_ADC_MEM_DST_BASE));
//DMA_ADC_MEM_TD[0] = CyDmaTdAllocate();
//CyDmaTdSetConfiguration(DMA_ADC_MEM_TD[0], 1024, CY_DMA_DISABLE_TD, DMA_ADC_MEM__TD_TERMOUT_EN | CY_DMA_TD_INC_DST_ADR);
//CyDmaTdSetAddress(DMA_ADC_MEM_TD[0], LO16((uint32)ADC_DelSig_DEC_SAMP_PTR), LO16((uint32)ADCBuffer));
//CyDmaChSetInitialTd(DMA_ADC_MEM_Chan, DMA_ADC_MEM_TD[0]);
//CyDmaChEnable(DMA_ADC_MEM_Chan, 1);
// #endif  
//
///* DMA Configuration for DMA_ADC_MEM */
//DMA_ADC_MEM_Chan = DMA_ADC_MEM_DmaInitialize(DMA_ADC_MEM_BYTES_PER_BURST, DMA_ADC_MEM_REQUEST_PER_BURST, 
//    HI16(DMA_ADC_MEM_SRC_BASE), HI16(DMA_ADC_MEM_DST_BASE));
//DMA_ADC_MEM_TD[0] = CyDmaTdAllocate();
//CyDmaTdSetConfiguration(DMA_ADC_MEM_TD[0], 1024, CY_DMA_DISABLE_TD, DMA_ADC_MEM__TD_TERMOUT_EN | CY_DMA_TD_INC_DST_ADR);
//CyDmaTdSetAddress(DMA_ADC_MEM_TD[0], LO16((uint32)ADC_DelSig_DEC_SAMP_PTR), LO16((uint32)ADCBuffer));
//CyDmaChSetInitialTd(DMA_ADC_MEM_Chan, DMA_ADC_MEM_TD[0]);
//CyDmaChEnable(DMA_ADC_MEM_Chan, 1);
//
//
///* DMA Configuration for DMA_MEM_UART */
//DMA_MEM_UART_Chan = DMA_MEM_UART_DmaInitialize(DMA_MEM_UART_BYTES_PER_BURST, DMA_MEM_UART_REQUEST_PER_BURST, 
//    HI16(DMA_MEM_UART_SRC_BASE), HI16(DMA_MEM_UART_DST_BASE));
//DMA_MEM_UART_TD[0] = CyDmaTdAllocate();
//CyDmaTdSetConfiguration(DMA_MEM_UART_TD[0], 1024, CY_DMA_DISABLE_TD, DMA_MEM_UART__TD_TERMOUT_EN | CY_DMA_TD_INC_SRC_ADR);
//CyDmaTdSetAddress(DMA_MEM_UART_TD[0], LO16((uint32)ADCBuffer), LO16((uint32)UART_LOG_TXDATA_PTR));
//CyDmaChSetInitialTd(DMA_MEM_UART_Chan, DMA_MEM_UART_TD[0]);
//CyDmaChEnable(DMA_MEM_UART_Chan, 1);

    
/* DMA Configuration for DMA_ADC_MEM */
DMA_ADC_MEM_Chan = DMA_ADC_MEM_DmaInitialize(DMA_ADC_MEM_BYTES_PER_BURST, DMA_ADC_MEM_REQUEST_PER_BURST, 
    HI16(DMA_ADC_MEM_SRC_BASE), HI16(DMA_ADC_MEM_DST_BASE));
DMA_ADC_MEM_TD[0] = CyDmaTdAllocate();
CyDmaTdSetConfiguration(DMA_ADC_MEM_TD[0], 2048, CY_DMA_DISABLE_TD, DMA_ADC_MEM__TD_TERMOUT_EN | CY_DMA_TD_INC_DST_ADR);
CyDmaTdSetAddress(DMA_ADC_MEM_TD[0], LO16((uint32)ADC_DelSig_DEC_SAMP_PTR), LO16((uint32)ADCBuffer));
CyDmaChSetInitialTd(DMA_ADC_MEM_Chan, DMA_ADC_MEM_TD[0]);
CyDmaChEnable(DMA_ADC_MEM_Chan, 1);



/* DMA Configuration for DMA_MEM_UART */
DMA_MEM_UART_Chan = DMA_MEM_UART_DmaInitialize(DMA_MEM_UART_BYTES_PER_BURST, DMA_MEM_UART_REQUEST_PER_BURST, 
    HI16(DMA_MEM_UART_SRC_BASE), HI16(DMA_MEM_UART_DST_BASE));
DMA_MEM_UART_TD[0] = CyDmaTdAllocate();
CyDmaTdSetConfiguration(DMA_MEM_UART_TD[0], 2048, CY_DMA_DISABLE_TD, DMA_MEM_UART__TD_TERMOUT_EN | CY_DMA_TD_INC_SRC_ADR);
CyDmaTdSetAddress(DMA_MEM_UART_TD[0], LO16((uint32)ADCBuffer), LO16((uint32)UART_LOG_TXDATA_PTR));
CyDmaChSetInitialTd(DMA_MEM_UART_Chan, DMA_MEM_UART_TD[0]);




    
    SetRelAlarm(alrm_main,1,1000);
    //Start the alarm with 100ms cycle time
    
    

    ActivateTask(tsk_background);

    TerminateTask();
    
}



TASK(tsk_background)
{
    
    
    while(1)
    {
       

    }
    TerminateTask();
    
}

TASK(tsk_control)
{
    
    LED_Toggle(LED_GREEN);
    
    WaveDAC8_Start();
    ADC_DelSig_StartConvert();
    
    //WaveDAC8_Start();
//    WaveDAC8_Enable();
    
//    ADC_DelSig_StartConvert();
//    
//    while (1){
//        if (ADC_DelSig_IsEndConversion(ADC_DelSig_RETURN_STATUS)){
//            uint8_t conversionResult = ADC_DelSig_GetResult8();
//            
//            UART_LOG_PutChar(conversionResult);
//            
//        }
//        
//    }
//    
//    ADC_DelSig_stopConversion;
    
    TerminateTask();
    
}

ISR2(UART_Rx_ISR){
    
#define CASE 0
    
    #if CASE == 0
    WaveDAC8_Start();
ADC_DelSig_StartConvert();
    
uint16_t i = 0;
    while (i < 512){
        if (ADC_DelSig_IsEndConversion(ADC_DelSig_RETURN_STATUS)){
            uint16_t conversionResult = ADC_DelSig_GetResult16();
            
            uint8_t upper_byte = (conversionResult >> 8) & 0xFF;
            uint8_t lower_byte = conversionResult & 0xFF;
            
            
            
            UART_LOG_PutChar(upper_byte);
            UART_LOG_PutChar(lower_byte);
            
            UART_LOG_PutChar(i);
            i = i + 1;
            
//            if (i == 1023){
//                UART_LOG_PutChar(i);
//            }
        }
        
    }
    ADC_DelSig_stopConversion;
    #endif
    
    #if CASE == 1
    UART_RX_isrHandler();
    #endif
    
    #if CASE == 2
    WaveDAC8_Start();
    ADC_DelSig_StartConvert();
    
    uint16_t i = 0;
    while (i < 256){
        if (ADC_DelSig_IsEndConversion(ADC_DelSig_RETURN_STATUS)){
            uint8_t conversionResult = ADC_DelSig_GetResult16();

            
            UART_LOG_PutChar(conversionResult);
            
            // Chane ADC resolution to 8 bit
            // 100 - 2000
        }
        
    }
    ADC_DelSig_stopConversion;
    #endif
    
}

ISR2(isr_DMA_ADC_MEM){
//UART_LOG_PutChar('A');

//for (int i = 0; i < 1024; ++i){
//    UART_LOG_PutChar(ADCBuffer[i]);
//    UART_LOG_PutString("\n");
//}

CyDmaChEnable(DMA_MEM_UART_Chan, 1);
}

ISR2(isr_DMA_MEM_UART){
    UART_LOG_PutString("Done");

}

/********************************************************************************
 * ISR Definitions
 ********************************************************************************/

/* [] END OF FILE */
